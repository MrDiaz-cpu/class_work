"use strict";
const $ = id => document.getElementById(id);
const canvas = $("board"), ctx = canvas.getContext("2d");
let levels = {}, selected = "tutorial", result = null, index = 0, timer = null;
let playing = false, busy = false, frame = null, tween = null, demo = false;
const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

function stop() { clearTimeout(timer); timer = null; playing = false; $("pause").textContent = "Play"; }
function status(text, type = "") { $("status").textContent = text; $("status").className = "status " + type; }
function initialFrame(level) { return {position:level.start, remaining:level.crystals, moves:0, action:"Ready", line:null}; }
function source(text) {
  $("code").replaceChildren();
  text.split("\n").forEach((line, i) => {
    const row = document.createElement("div"); row.className = "code-line"; row.dataset.line = i + 1;
    const number = document.createElement("span"); number.className = "number"; number.textContent = i + 1;
    const content = document.createElement("span"); content.textContent = line || " ";
    row.append(number, content); $("code").append(row);
  });
}
function show(nextIndex, animate = true) {
  if (!result) return;
  index = Math.max(0, Math.min(nextIndex, result.events.length - 1));
  const next = result.events[index], previous = frame;
  tween = animate && !reducedMotion && previous ? {from:previous.position, to:next.position, start:performance.now()} : null;
  frame = next;
  const level = result.level;
  $("crystals").textContent = `${level.crystals.length - next.remaining.length} / ${level.crystals.length}`;
  $("moves").textContent = `${next.moves} / ${level.move_limit}`;
  $("progress").textContent = `${index} / ${result.events.length - 1}`;
  document.querySelectorAll(".code-line.active").forEach(el => el.classList.remove("active"));
  const line = next.line && document.querySelector(`.code-line[data-line="${next.line}"]`);
  if (line) { line.classList.add("active"); const top = line.offsetTop - $("code").offsetTop;
    if (top < $("code").scrollTop || top > $("code").scrollTop + $("code").clientHeight - 30) $("code").scrollTop = Math.max(0, top - 70);
  }
  $("log").replaceChildren();
  result.events.slice(1, index + 1).forEach(event => {const item = document.createElement("li"); item.textContent = `${event.action}${event.line ? " · line " + event.line : ""}`; $("log").append(item);});
  $("step").disabled = index === result.events.length - 1;
  if (index === result.events.length - 1) {
    stop();
    status(result.message + (result.error && result.error.line ? ` (line ${result.error.line})` : ""), result.error ? "error" : result.won ? "won" : "");
  } else status(index === 0 ? "Ready. Predict the next action, then play or step through." : `${next.action}${next.line ? " · Python line " + next.line : ""}`);
}
function advance() { if (!playing || !result) return; show(index + 1); if (playing) timer = setTimeout(advance, Number($("speed").value)); }
function play() { if (!result || result.events.length < 2) return; if(index >= result.events.length - 1) show(0, false); playing = true; $("pause").textContent = "Pause"; timer = setTimeout(advance, Number($("speed").value)); }

async function run() {
  if (busy) return;
  stop(); busy = true; result = null;
  $("run").disabled = true; $("run").textContent = "Running Python…";
  document.querySelectorAll(".tab").forEach(b => b.disabled = true);
  $("replay").disabled = $("pause").disabled = $("step").disabled = true;
  frame = initialFrame(levels[selected]); tween = null;
  $("crystals").textContent = `0 / ${levels[selected].crystals.length}`;
  $("moves").textContent = `0 / ${levels[selected].move_limit}`;
  $("progress").textContent = "0 / 0"; $("log").replaceChildren(); source("");
  $("filename").textContent = selected === "tutorial" ? "tutorial.py" : "mission.py";
  $("stdout").textContent = "No print output.";
  status("Reading your saved Python…");
  try {
    const response = await fetch("/api/run", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({level:selected})});
    const data = await response.json();
    if (!response.ok || data.server_error || data.error && !data.events) throw Error(data.server_error || data.error || "Run failed.");
    result = data; source(data.source); $("filename").textContent = data.filename;
    $("mode").textContent = data.mode; $("stdout").textContent = data.stdout || "No print output.";
    $("connection").textContent = demo ? "Connected · teacher reference" : "Connected · your Python";
    $("connection").classList.remove("offline");
    $("replay").disabled = $("pause").disabled = false;
    show(0, false); if (!reducedMotion) play();
  } catch (error) {
    status(error.message + " If disconnected, keep python play.py running and reopen the forwarded port.", "error");
    $("connection").textContent = "Run unavailable"; $("connection").classList.add("offline");
  } finally {
    busy = false; $("run").disabled = false; $("run").textContent = "▶ Run saved Python";
    document.querySelectorAll(".tab").forEach(b => b.disabled = false);
  }
}
$("run").onclick = run;
$("pause").onclick = () => playing ? stop() : play();
$("step").onclick = () => { stop(); show(index + 1); };
$("replay").onclick = () => { stop(); show(0, false); if (!reducedMotion) play(); };
document.querySelectorAll(".tab").forEach(button => button.onclick = () => {
  selected = button.dataset.level; document.querySelectorAll(".tab").forEach(b => b.classList.toggle("selected", b === button));
  $("level-title").textContent = levels[selected].title;
  $("prompt").textContent = selected === "tutorial" ? "Start with one move. Then make the repetition visible." : selected === "challenge" ? "What repeats in this staircase? Name it, then reuse it." : "Same route. New crystals. Does your saved code still work?";
  run();
});

function rounded(x,y,w,h,r,fill,stroke) { ctx.beginPath(); ctx.roundRect(x,y,w,h,r); if(fill){ctx.fillStyle=fill;ctx.fill();} if(stroke){ctx.strokeStyle=stroke;ctx.stroke();} }
function diamond(x,y,size) {ctx.fillStyle="#79dedc";ctx.beginPath();ctx.moveTo(x,y-size);ctx.lineTo(x+size*.68,y);ctx.lineTo(x,y+size);ctx.lineTo(x-size*.68,y);ctx.closePath();ctx.fill();ctx.fillStyle="#c0ffed";ctx.beginPath();ctx.moveTo(x,y-size);ctx.lineTo(x,y+size);ctx.lineTo(x-size*.68,y);ctx.closePath();ctx.fill();}
function robot(x,y,s){
  ctx.fillStyle="rgba(0,0,0,.25)";ctx.beginPath();ctx.ellipse(x,y+s*.32,s*.34,s*.11,0,0,Math.PI*2);ctx.fill();
  rounded(x-s*.28,y-s*.23,s*.56,s*.49,s*.08,"#e8edcb");
  rounded(x-s*.2,y-s*.13,s*.4,s*.18,s*.035,"#244944");
  ctx.fillStyle="#a0f7dc";ctx.fillRect(x-s*.12,y-s*.08,s*.065,s*.065);ctx.fillRect(x+s*.055,y-s*.08,s*.065,s*.065);
  rounded(x-s*.2,y+s*.22,s*.13,s*.13,2,"#a6b6a0");rounded(x+s*.07,y+s*.22,s*.13,s*.13,2,"#a6b6a0");
  ctx.strokeStyle="#cbdab9";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y-s*.23);ctx.lineTo(x,y-s*.36);ctx.stroke();
  ctx.fillStyle="#d7f18b";ctx.beginPath();ctx.arc(x,y-s*.39,s*.055,0,Math.PI*2);ctx.fill();
}
function paint(time) {
  ctx.fillStyle="#182d2a";ctx.fillRect(0,0,880,570);
  const level = result ? result.level : levels[selected];
  if (level && frame) {
    const rows=level.grid.length, cols=level.grid[0].length;
    const size=Math.min(70,776/cols,478/rows), ox=(880-cols*size)/2, oy=(570-rows*size)/2;
    ctx.font="10px monospace";ctx.textAlign="center";
    for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
      const wall=level.grid[y][x]==="#", px=ox+x*size, py=oy+y*size;
      rounded(px+2,py+2,size-4,size-4,4,wall?"#223b36":"#36564a",wall?"#2a443d":"#496859");
      if(wall){ctx.fillStyle="#29443c";ctx.fillRect(px+size*.28,py+size*.47,size*.44,2);}
      if(!wall){ctx.fillStyle="#456653";ctx.fillRect(px+size*.2,py+size*.8,3,3);}
    }
    ctx.fillStyle="#92a899";
    for(let x=0;x<cols;x++)ctx.fillText(x,ox+(x+.5)*size,oy-12);
    for(let y=0;y<rows;y++)ctx.fillText(y,ox-16,oy+(y+.55)*size);
    const [ex,ey]=level.exit, epX=ox+(ex+.5)*size, epY=oy+(ey+.5)*size;
    ctx.lineWidth=2;rounded(epX-size*.34,epY-size*.36,size*.68,size*.7,6,"#48643a","#b9de7a");
    ctx.fillStyle="#d7ef9c";ctx.font=`bold ${size*.19}px monospace`;ctx.fillText("EXIT",epX,epY+size*.07);
    frame.remaining.forEach(([x,y])=>diamond(ox+(x+.5)*size,oy+(y+.5)*size,size*.23));
    let [rx,ry]=frame.position;
    if(tween){const duration=Math.min(310,Number($("speed").value)*.8), t=Math.min(1,(time-tween.start)/duration), e=t*t*(3-2*t);rx=tween.from[0]+(tween.to[0]-tween.from[0])*e;ry=tween.from[1]+(tween.to[1]-tween.from[1])*e;if(t===1)tween=null;}
    robot(ox+(rx+.5)*size,oy+(ry+.5)*size,size);
    ctx.fillStyle="#93ab99";ctx.font="11px monospace";ctx.textAlign="left";ctx.fillText("ROUTE / "+selected.toUpperCase(),28,18);
    ctx.textAlign="right";ctx.fillText("PYTHON → MOVEMENT",852,18);
  }
  requestAnimationFrame(paint);
}
requestAnimationFrame(paint);
fetch("/api/levels").then(r=>{if(!r.ok)throw Error();return r.json();}).then(data=>{levels=data.levels;demo=data.demo;frame=initialFrame(levels.tutorial);run();}).catch(()=>{status("Cannot connect. Start python play.py and open its forwarded port.","error");$("connection").textContent="Disconnected";$("connection").classList.add("offline");});
