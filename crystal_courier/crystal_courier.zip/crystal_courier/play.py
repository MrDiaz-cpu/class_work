"""Run: python play.py. Open the forwarded port 8080 in cs50.dev."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlsplit

from levels import LEVELS

ROOT = Path(__file__).resolve().parent


def simulate(level_id, demo=False):
    if level_id not in LEVELS:
        raise ValueError("Unknown level.")
    filename = "tutorial.py" if level_id == "tutorial" else "mission.py"
    script = ROOT / "teacher_only" / filename if demo else ROOT / filename
    if not script.is_file():
        return {"server_error": "Teacher reference files are not in this copy. Start without --demo."}
    try:
        result = subprocess.run([sys.executable, "-B", str(ROOT / "runner.py"), str(script), level_id],
                                cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True,
                                text=True, timeout=3)
    except subprocess.TimeoutExpired:
        return {"server_error": "Python took longer than 3 seconds. Check your loops, save, and run again."}
    try:
        data = json.loads(result.stdout)
    except (json.JSONDecodeError, ValueError):
        return {"server_error": "Python could not finish this run. " + result.stderr[-1800:]}
    data["mode"] = "Teacher reference" if demo else "Your saved Python"
    return data


def make_handler(demo=False):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, data, mime="application/json", status=200):
            body = json.dumps(data).encode() if mime == "application/json" else data
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == "/api/levels":
                return self.send({"levels": LEVELS, "demo": demo})
            assets = {"/": ("index.html", "text/html; charset=utf-8"),
                      "/style.css": ("style.css", "text/css; charset=utf-8"),
                      "/app.js": ("app.js", "text/javascript; charset=utf-8")}
            if path not in assets:
                return self.send({"error": "Not found"}, status=404)
            filename, mime = assets[path]
            self.send((ROOT / "web" / filename).read_bytes(), mime)

        def do_POST(self):
            if urlsplit(self.path).path != "/api/run":
                return self.send({"error": "Not found"}, status=404)
            # Browser UI and API share one origin; reject cross-origin browser writes.
            origin = self.headers.get("Origin")
            if origin and urlsplit(origin).netloc != self.headers.get("Host"):
                return self.send({"error": "Open the game in its own forwarded tab."}, status=403)
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length < 1024:
                    raise ValueError("Invalid request size.")
                request = json.loads(self.rfile.read(length))
                if not isinstance(request, dict) or request.get("level") not in LEVELS:
                    raise ValueError("Choose one of the supplied levels.")
                self.send(simulate(request["level"], demo))
            except (ValueError, TypeError):
                self.send({"error": "Choose one of the supplied levels."}, status=400)
    return Handler


def main():
    parser = argparse.ArgumentParser(description="Crystal Courier visual Python game")
    parser.add_argument("--demo", action="store_true", help="Run completed teacher reference files")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--check", choices=list(LEVELS), help="Check saved Python without opening a browser")
    args = parser.parse_args()
    if args.check:
        result = simulate(args.check, args.demo)
        if "server_error" in result:
            print(result["server_error"])
            return 1
        print(result["message"])
        if result["error"]:
            print(f'Line {result["error"]["line"]}: {result["error"]["type"]}')
        print(f'Moves: {result["moves"]} / {result["level"]["move_limit"]}')
        return 0 if result["won"] else 1
    try:
        server = ThreadingHTTPServer(("0.0.0.0", args.port), make_handler(args.demo))
    except OSError as exc:
        print(f"Cannot start port {args.port}: {exc}\nTry: python play.py --port {args.port + 1}")
        return 1
    print(f"\nCRYSTAL COURIER — {'TEACHER REFERENCE' if args.demo else 'YOUR SAVED PYTHON'}", flush=True)
    print(f"Game is running: http://localhost:{args.port}", flush=True)
    print(f"In cs50.dev: Ports → {args.port} → Open in Browser. Keep the port Private.", flush=True)
    print("Save tutorial.py or mission.py; click Run saved Python. Leave this terminal running.", flush=True)
    print("Stop with Ctrl+C.\n", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nGame stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
