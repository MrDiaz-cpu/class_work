# Defend the Base

Read STUDENT_INSTRUCTIONS.md. Begin with `python tower_demo.py`, then launch the game with `python game.py`.
