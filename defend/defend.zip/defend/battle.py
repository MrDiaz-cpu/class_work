"""Shared class example: the outer loop. The server supplies attack."""


def play_wave(health, damages, distance):
    turns = []

    while health > 0 and distance > 0:
        before = health
        health = attack(health, damages)

        # These records let the supplied animation display what Python did.
        turns.append({"distance": distance, "before": before, "after": health})

        if health > 0:
            distance = distance - 1

    return {"turns": turns, "health": health, "distance": distance}
