"""Supplied server and browser launcher. Students edit only defenders.py.

No third-party Python packages are needed. Keep Codespaces port visibility private.
"""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
from urllib.parse import urlparse
import webbrowser

ROOT = Path(__file__).resolve().parent
SCENARIOS = [
    {"id": "scout", "name": "Scout", "health": 5, "distance": 3, "damages": [2, 1], "description": "A quick first test. Two towers, three chances."},
    {"id": "raider", "name": "Raider", "health": 8, "distance": 3, "damages": [2, 1], "description": "It will get close. Does your loop use both towers?"},
    {"id": "tank", "name": "Tank", "health": 10, "distance": 3, "damages": [2, 1], "description": "A tougher enemy. Predict whether these towers can stop it."},
    {"id": "squad", "name": "Three towers", "health": 11, "distance": 3, "damages": [1, 2, 1], "description": "One more tower. Your function should handle any list length."},
]
ASSETS = {"/": ("index.html", "text/html; charset=utf-8"),
          "/style.css": ("style.css", "text/css; charset=utf-8"),
          "/app.js": ("app.js", "text/javascript; charset=utf-8")}


def simulate(scenario, demo=False):
    try:
        process = subprocess.run(
            [sys.executable, "-B", str(ROOT / "engine/runner.py"), "demo" if demo else "student"],
            input=json.dumps(scenario), capture_output=True, text=True,
            cwd=ROOT, timeout=3,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Your Python took more than 3 seconds. Check that every loop can finish."}
    if process.returncode != 0:
        return {"ok": False, "error": "Python stopped unexpectedly. Check defenders.py and try again."}
    try:
        result = json.loads(process.stdout)
    except (ValueError, TypeError):
        return {"ok": False, "error": "Python could not return a result. Check defenders.py and try again."}
    result["scenario"] = scenario
    return result


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def send_bytes(self, status, content, mime):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'")
        self.end_headers()
        try:
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_json(self, status, value):
        self.send_bytes(status, json.dumps(value).encode(), "application/json; charset=utf-8")

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/config":
            source = ROOT / ("teacher_only/solution.py" if self.server.demo else "defenders.py")
            try:
                code = source.read_text()[:10000]
            except (OSError, UnicodeError):
                code = "Could not read the Python file. Check that defenders.py exists and is saved as UTF-8."
            self.send_json(200, {"scenarios": SCENARIOS, "mode": "demo" if self.server.demo else "student",
                                 "file": "teacher_only/solution.py" if self.server.demo else "defenders.py", "code": code})
        elif path in ASSETS:
            filename, mime = ASSETS[path]
            self.send_bytes(200, (ROOT / "web" / filename).read_bytes(), mime)
        else:
            self.send_json(404, {"ok": False, "error": "Not found"})

    def do_POST(self):
        if urlparse(self.path).path != "/api/run":
            self.send_json(404, {"ok": False, "error": "Not found"})
            return
        origin = self.headers.get("Origin")
        allowed_hosts = {self.headers.get("Host", ""), self.server.public_host}
        if origin and urlparse(origin).netloc not in allowed_hosts:
            self.send_json(403, {"ok": False, "error": "Open the game from its own server address."})
            return
        if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
            self.send_json(415, {"ok": False, "error": "Expected JSON."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 1024:
                raise ValueError()
            request = json.loads(self.rfile.read(length))
            scenario = next(s for s in SCENARIOS if s["id"] == request["scenario"])
        except (ValueError, KeyError, TypeError, StopIteration):
            self.send_json(400, {"ok": False, "error": "Choose one of the available waves."})
            return
        self.send_json(200, simulate(scenario, self.server.demo))


def main():
    parser = argparse.ArgumentParser(description="Defend the Base — Python controls the battle.")
    parser.add_argument("--demo", action="store_true", help="use the private teacher reference solution")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--host", default="0.0.0.0", help=argparse.SUPPRESS)
    parser.add_argument("--strictPort", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8080")))
    args = parser.parse_args()
    if args.demo and not (ROOT / "teacher_only/solution.py").exists():
        parser.error("Demo mode needs the teacher package. Run without --demo to use defenders.py.")
    try:
        server = ThreadingHTTPServer((args.host, args.port), Handler)
    except OSError as error:
        parser.exit(1, f"Could not start port {args.port}: {error}\nTry python game.py --port 8081\n")
    server.demo = args.demo
    local_url = f"http://localhost:{server.server_port}"
    codespace = os.environ.get("CODESPACE_NAME")
    forwarding_domain = os.environ.get("GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN", "app.github.dev")
    browser_url = f"https://{codespace}-{server.server_port}.{forwarding_domain}" if codespace else local_url
    server.public_host = urlparse(browser_url).netloc
    print(f"\nDefend the Base — {'TEACHER DEMO' if args.demo else 'YOUR PYTHON'}", flush=True)
    print(f"Server ready: {local_url}", flush=True)
    if codespace:
        print(f"Browser: {browser_url}", flush=True)
    print("If a tab does not open, use the Ports panel → Open in Browser.", flush=True)
    print("Save defenders.py, then click Launch wave. Ctrl+C stops the server.\n", flush=True)
    if not args.no_browser:
        threading.Thread(target=webbrowser.open, args=(browser_url,), kwargs={"new": 2}, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nGame server stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
