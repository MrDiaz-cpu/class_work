"""Your assignment: finish attack, then save and launch a wave again."""


def attack(health, damages):
    # health is the enemy's current health: a nonnegative integer.
    # damages is a list of nonnegative integers, one per tower.
    # TODO: Use a for loop to subtract each tower's damage.
    # TODO: Return 0 if the result would be negative.
    # Return the remaining health. Do not print the answer.
    return health
