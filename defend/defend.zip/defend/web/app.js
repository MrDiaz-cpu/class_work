'use strict';
const $ = id => document.getElementById(id);
const canvas = $('board'), ctx = canvas.getContext('2d');
let config, scenario, replay = null, nextTurn = 0, busy = false, token = 0;
let enemy = {x:792, health:5, maximum:5, alive:true, scale:1};
let beams = [], sparks = [], breach = false, towerFlash = 0;
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const gridX = d => 125 + d * 222;
const colors = {'.':null, a:'#10272d', b:'#265253', c:'#4b8b79', d:'#b5e887', e:'#e1ffac', f:'#73dcda', g:'#dd688c', h:'#874666', i:'#ffd8be', j:'#eef8eb'};
// Original pixel sprites. Each character is one square in a tiny image.
const robot = ['...aaaaaa...','..ahhhhhha..','.ahggggggha.','.ahgiiggiha.','.ahggggggha.','..ahhhhhha..','...aaaaaa...','..ahgghhha..','.ahggghhhha.','aahggghhhhaa','aa.aaaaaa.aa','...ah..ha...','..aaa..aaa..'];
const base = ['......aa......','.....aff a....'.replace(' ',''),'....affffa....','....afeefa....','.....affa.....','..aa..aa..aa..','..acaaaaaaca..','..acccccccca..','..acbbbbbbca..','aaacbffffbcaaa','acccbfjjfbccca','acccbfjjfbccca','acccbfjjfbccca','acccbbbbbbccca','aaaaaaaaaaaaaa'];
function sprite(pattern,x,y,s,palette=colors){pattern.forEach((row,ry)=>[...row].forEach((c,rx)=>{if(palette[c]){ctx.fillStyle=palette[c];ctx.fillRect(Math.round(x+rx*s),Math.round(y+ry*s),s,s);}}));}
function text(str,x,y,size=12,color='#aac9b7',align='center'){ctx.fillStyle=color;ctx.font=`${size}px ui-monospace, monospace`;ctx.textAlign=align;ctx.fillText(str,x,y);}
function towerPositions(){const n=scenario?.damages.length||2;return Array.from({length:n},(_,i)=>({x:365+i*165,y:i%2===0?207:375}));}
function drawTower(t,i){ctx.fillStyle='#0b2528';ctx.fillRect(t.x-27,t.y-4,54,26);ctx.fillStyle='#436a60';ctx.fillRect(t.x-23,t.y-9,46,23);ctx.fillStyle='#729f85';ctx.fillRect(t.x-18,t.y-13,36,14);ctx.fillStyle='#183c40';ctx.fillRect(t.x-16,t.y-31,32,24);ctx.fillStyle=towerFlash?'#eaffaa':'#7bdace';ctx.fillRect(t.x-11,t.y-28,22,7);ctx.save();ctx.translate(t.x,t.y-22);ctx.rotate(Math.atan2(292-(t.y-22),enemy.x-t.x));ctx.fillStyle='#203d43';ctx.fillRect(-3,-6,31,12);ctx.fillStyle='#a1c8ad';ctx.fillRect(15,-4,18,8);ctx.restore();text(`T${i+1} · ${scenario?.damages[i]??0} DMG`,t.x,t.y+(t.y>300?42:-48),11,'#b7ddd1');}
function draw(){
  ctx.clearRect(0,0,960,480);ctx.fillStyle='#234538';ctx.fillRect(0,0,960,480);
  for(let y=0;y<480;y+=32)for(let x=0;x<960;x+=32){const n=(x*7+y*11)%97;ctx.fillStyle=n<35?'#294d3d':n<65?'#244939':'#204232';ctx.fillRect(x,y,31,31);if(n<23){ctx.fillStyle='#365a42';ctx.fillRect(x+9,y+15,3,7);ctx.fillRect(x+12,y+11,3,10);}}
  ctx.fillStyle='#19392f';ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(960,0);ctx.lineTo(960,91);ctx.lineTo(806,72);ctx.lineTo(689,99);ctx.lineTo(500,56);ctx.lineTo(290,95);ctx.lineTo(119,69);ctx.lineTo(0,101);ctx.fill();
  // Broken stonework, bushes, and small terrain details.
  for(const [x,y] of [[58,147],[865,147],[240,405],[871,402],[702,127]]){ctx.fillStyle='#15382d';ctx.fillRect(x-14,y-8,36,21);ctx.fillStyle='#426b49';ctx.fillRect(x-12,y-20,24,16);ctx.fillStyle='#5a8055';ctx.fillRect(x-5,y-24,13,9);}
  ctx.fillStyle='#152e2b';ctx.fillRect(0,261,960,78);ctx.fillStyle='#627064';ctx.fillRect(0,267,960,62);ctx.fillStyle='#727c6c';ctx.fillRect(0,267,960,5);ctx.fillStyle='#46594d';ctx.fillRect(0,324,960,6);
  for(let x=0;x<960;x+=54){ctx.fillStyle='#536359';ctx.fillRect(x,272,2,52);ctx.fillRect(x+2,296,52,2);ctx.fillStyle='#818778';ctx.fillRect(x+8,279,19,2);}
  for(let d=1;d<=3;d++){ctx.strokeStyle='#b1c9a647';ctx.setLineDash([3,6]);ctx.beginPath();ctx.moveTo(gridX(d),251);ctx.lineTo(gridX(d),342);ctx.stroke();ctx.setLineDash([]);text(`${d} SPACE${d===1?'':'S'}`,gridX(d),359,10,'#b4c6a7');}
  text('NORTH RIDGE',205,121,10,'#73977c');text('ENEMY APPROACH',818,232,10,'#bed2b0');
  ctx.fillStyle='#183b36';ctx.fillRect(35,230,120,122);ctx.fillStyle='#456e59';ctx.fillRect(40,230,110,109);sprite(base,42,216,7);text('YOUR BASE',91,380,12,breach?'#ffaca3':'#d0edbc');
  towerPositions().forEach(drawTower);
  if(enemy.alive){ctx.save();ctx.translate(enemy.x,304);ctx.scale(enemy.scale,enemy.scale);ctx.fillStyle='#0c252b55';ctx.beginPath();ctx.ellipse(0,5,27,9,0,0,Math.PI*2);ctx.fill();sprite(robot,-30,-63,5);ctx.restore();const bw=72;ctx.fillStyle='#112b2b';ctx.fillRect(enemy.x-bw/2,217,bw,9);ctx.fillStyle=enemy.health/enemy.maximum>.35?'#dc7598':'#ffb987';ctx.fillRect(enemy.x-bw/2+2,219,(bw-4)*Math.max(0,enemy.health/enemy.maximum),5);text(`${enemy.health} / ${enemy.maximum}`,enemy.x,208,12,'#ffe2de');}
  for(const b of beams){ctx.strokeStyle=`rgba(205,252,134,${b.alpha})`;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.x+(b.tx-b.x)*b.progress,b.y+(b.ty-b.y)*b.progress);ctx.stroke();ctx.fillStyle='#f4ffbb';ctx.fillRect(b.x+(b.tx-b.x)*b.progress-4,b.y+(b.ty-b.y)*b.progress-4,8,8);}
  for(const p of sparks){ctx.fillStyle=p.color;ctx.globalAlpha=p.alpha;ctx.fillRect(p.x,p.y,p.size,p.size);ctx.globalAlpha=1;}
  if(breach){ctx.fillStyle='#ff786620';ctx.fillRect(0,180,190,215);}
  text('DEFENSE GRID 03',28,35,11,'#9dbba7','left');text('PYTHON CONNECTED',930,35,10,'#9dbba7','right');
}
function status(title,copy,kind=''){ $('status').className='status '+kind;$('status-title').textContent=title;$('status-copy').textContent=copy;}
function refresh(){ $('enemy-health').textContent=enemy.health+' HP';$('turn-count').textContent=`${nextTurn} / ${scenario?.distance||3}`;$('base-status').textContent=breach?'BREACHED':'SECURE';$('launch').disabled=busy||!config;$('step').disabled=busy||!replay||nextTurn>=replay.turns.length;draw(); }
function renderScenario(){
  $('wave-hint').textContent=scenario.description;$('function-call').textContent=`attack(${scenario.health}, [${scenario.damages.join(', ')}])`;
  document.querySelectorAll('.scenario').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.id===scenario.id)));
  $('towers').replaceChildren();scenario.damages.forEach((damage,i)=>{const row=document.createElement('div');row.className='tower';const icon=document.createElement('span');icon.className='tower-icon';icon.textContent='▥';icon.setAttribute('aria-hidden','true');const label=document.createElement('span');label.className='tower-name';label.textContent='Tower '+(i+1);const sub=document.createElement('small');sub.textContent='Fires once per turn';label.append(sub);const amount=document.createElement('b');amount.textContent=damage+' DMG';row.append(icon,label,amount);$('towers').append(row);});
}
function reset(){token++;busy=false;replay=null;nextTurn=0;beams=[];sparks=[];breach=false;towerFlash=0;enemy={x:gridX(scenario.distance),health:scenario.health,maximum:scenario.health,alive:true,scale:1};$('phase').textContent='AWAITING COMMAND';$('turn-log').replaceChildren();const empty=document.createElement('li');empty.className='empty-log';empty.textContent='Launch a wave to see your function in action.';$('turn-log').append(empty);status('Towers ready. Code ready?',`Enemy: ${scenario.health} HP. Three spaces to the base. Predict the outcome, then launch.`);refresh();}
async function tween(ms,update,id){if(reducedMotion.matches){if(id!==token)return false;update(1);draw();return true;}const duration=ms/Number($('speed').value);return new Promise(resolve=>{const start=performance.now();function frame(t){if(id!==token){resolve(false);return;}const p=Math.min(1,(t-start)/duration);update(p);draw();if(p<1)requestAnimationFrame(frame);else resolve(true);}requestAnimationFrame(frame);});}
function addLog(turn,index){const row=document.createElement('li');const num=document.createElement('span');num.textContent=String(index+1).padStart(2,'0');const call=document.createElement('code');call.textContent=`attack(${turn.before}, [${scenario.damages.join(', ')}])`;const result=document.createElement('span');result.className='result';result.textContent=`→ ${turn.after} HP`;row.append(num,call,result);$('turn-log').append(row);}
async function advance(){
  if(busy||!replay||nextTurn>=replay.turns.length)return;busy=true;refresh();const id=token;const turn=replay.turns[nextTurn];$('phase').textContent=`TURN ${nextTurn+1} / TOWERS FIRE`;status('Towers firing',`Your function receives ${turn.before} health and returns ${turn.after}.`);towerFlash=1;
  beams=towerPositions().map(t=>({x:t.x,y:t.y-22,tx:enemy.x,ty:278,alpha:1,progress:0}));
  if(!await tween(600,p=>{beams.forEach(b=>{b.progress=Math.min(1,p*1.6);b.alpha=1-p*.55;});},id))return;
  beams=[];towerFlash=0;enemy.health=turn.after;addLog(turn,nextTurn);nextTurn++;refresh();
  if(enemy.health===0){$('phase').textContent='ENEMY DEFEATED';sparks=Array.from({length:12},(_,i)=>({x:enemy.x,y:280,alpha:1,size:i%2?5:8,color:i%2?'#f9dc91':'#e87e98'}));const ex=enemy.x;
    if(!await tween(500,p=>{enemy.scale=1-p;sparks.forEach((s,i)=>{s.x=ex+Math.cos(i*2.4)*p*65;s.y=280+Math.sin(i*2.4)*p*55;s.alpha=1-p;});},id))return;
    enemy.alive=false;sparks=[];status('Base defended.',`${scenario.name} defeated in ${nextTurn} turn${nextTurn===1?'':'s'}. Save a change in your Python file to try another defense.`);
  }else{const start=enemy.x,end=gridX(turn.distance-1);$('phase').textContent='ENEMY ADVANCES';if(!await tween(900,p=>{enemy.x=start+(end-start)*(p*p*(3-2*p));},id))return;
    if(turn.distance===1){breach=true;$('phase').textContent='BASE BREACHED';status('The enemy reached your base.',`It survived with ${enemy.health} HP. Check the returned values: a stronger enemy can survive even correct code.`,'loss');}
    else{status('Next turn ready',`Enemy health: ${enemy.health}. Distance: ${turn.distance-1} space${turn.distance-1===1?'':'s'}.`);$('phase').textContent='BETWEEN TURNS';}}
  if(id!==token)return;busy=false;refresh();if($('autoplay').checked&&nextTurn<replay.turns.length)advance();
}
async function launch(){
  reset();const id=token;busy=true;refresh();status('Running your saved Python…','Each launch loads a fresh copy of the file.');$('phase').textContent='CALLING PYTHON';
  try{const [response,fresh]=await Promise.all([fetch('api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({scenario:scenario.id})}),fetch('api/config')]);const data=await response.json();const current=await fresh.json();if(id!==token)return;$('source').textContent=current.code;if(!response.ok||!data.ok)throw new Error(data.error||'The server could not run this wave.');replay=data.result;$('turn-log').replaceChildren();busy=false;status('Your Python is loaded.','Use Next turn to trace the battle, or turn on Autoplay.');$('phase').textContent='READY TO FIRE';refresh();if($('autoplay').checked)advance();
  }catch(error){if(id!==token)return;busy=false;replay=null;$('phase').textContent='CHECK YOUR CODE';status('Your function needs a fix.',error.message,'error');refresh();}
}
$('launch').addEventListener('click',launch);$('step').addEventListener('click',advance);$('reset').addEventListener('click',()=>{if(scenario)reset();});$('autoplay').addEventListener('change',()=>{if($('autoplay').checked)advance();});
async function boot(){try{const response=await fetch('api/config');if(!response.ok)throw new Error('The Python server is not responding.');config=await response.json();$('mode').textContent=config.mode==='demo'?'Teacher demo · reference code':'Connected · your Python';$('file-name').textContent=config.file;$('source').textContent=config.code;for(const s of config.scenarios){const b=document.createElement('button');b.className='scenario';b.dataset.id=s.id;b.setAttribute('aria-pressed','false');b.append(document.createTextNode(s.name));const hp=document.createElement('b');hp.textContent=s.health;const unit=document.createElement('small');unit.textContent='HP';hp.append(unit);b.append(hp);b.addEventListener('click',()=>{scenario=s;renderScenario();reset();});$('scenarios').append(b);}scenario=config.scenarios[0];renderScenario();reset();}catch(error){status('Start the Python server.',`${error.message} Run python game.py, then open its browser link.`,'error');draw();}}
boot();
