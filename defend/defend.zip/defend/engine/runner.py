"""Supplied infrastructure. Run a fresh copy of the student's saved Python.

This executes the local file, not code supplied by a browser. It is not a
security sandbox. The parent applies a deadline to catch accidental loops.
"""
import contextlib
import io
import json
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[1]


class DiscardOutput(io.TextIOBase):
    def write(self, text):
        return len(text)


def run():
    mode = sys.argv[1]
    source = ROOT / ("teacher_only/solution.py" if mode == "demo" else "defenders.py")
    request = json.load(sys.stdin)
    with contextlib.redirect_stdout(DiscardOutput()), contextlib.redirect_stderr(DiscardOutput()):
        namespace = runpy.run_path(str(source))
        attack = namespace.get("attack")
        if not callable(attack):
            raise ValueError("Define a function named attack(health, damages) in defenders.py.")

        def checked_attack(health, damages):
            result = attack(health, damages.copy())
            if type(result) is not int:
                raise ValueError("attack must return an integer. Use return, not print. "
                                 f"Received {type(result).__name__}.")
            if result < 0:
                raise ValueError("Health cannot be negative. Return 0 when the towers defeat the enemy.")
            if result > health:
                raise ValueError("An attack cannot increase the enemy's health. Check your subtraction.")
            return result

        battle = runpy.run_path(str(ROOT / "battle.py"), init_globals={"attack": checked_attack})
        result = battle["play_wave"](request["health"], request["damages"], request["distance"])
    result["won"] = result["health"] == 0
    return result


if __name__ == "__main__":
    try:
        result = {"ok": True, "result": run()}
    except BaseException as error:
        if isinstance(error, SyntaxError):
            message = f"Syntax error on line {error.lineno}: {error.msg}"
        else:
            message = f"{type(error).__name__}: {error}"
        result = {"ok": False, "error": message[:1200]}
    print(json.dumps(result))
